/* Declara o tipo booleano e suas constantes. */

#ifndef _Boolean_DEFINED
#define _Boolean_DEFINED


typedef enum {false, true} Boolean;

#endif
